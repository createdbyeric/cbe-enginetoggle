fx_version 'cerulean'
game 'gta5'

shared_script 'config.lua'

client_scripts {
    'main/client.lua'
}
